export const ACHEME = 'app'
export const LOAD_URL = `${ACHEME}://./index.html`
