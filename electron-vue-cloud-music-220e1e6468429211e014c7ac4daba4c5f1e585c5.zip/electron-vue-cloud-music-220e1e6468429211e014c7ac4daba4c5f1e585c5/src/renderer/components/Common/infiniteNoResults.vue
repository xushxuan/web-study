<template>
  <div class="no-result">暂无请求结果~</div>
</template>

<script>
export default {
  name: 'infiniteNoResults'
}
</script>

<style scoped>
  .no-result {
    margin: 15px 0;
    text-align: center;
  }
</style>
