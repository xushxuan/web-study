<template>
  <div class="no-more">没有更多了~</div>
</template>

<script>
export default {
  name: 'infiniteNoMore'
}
</script>

<style scoped>
  .no-more {
    margin: 15px 0;
    text-align: center;
  }
</style>
