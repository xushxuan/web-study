export default {
  primaryColor: '#c62f2f'
}
