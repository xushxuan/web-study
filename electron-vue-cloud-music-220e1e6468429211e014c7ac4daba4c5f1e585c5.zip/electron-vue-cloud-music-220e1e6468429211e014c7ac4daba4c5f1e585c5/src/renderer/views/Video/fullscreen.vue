<template>
  <div>
    <video class="video" controls="false" src="http://vodkgeyttp8.vod.126.net/cloudmusic/7049/core/93ba/fe4ac9aa6677ce319c4d21ee8be415e2.mp4?wsSecret=993f1822735ac6a03050423318c5943e&wsTime=1566391359"></video>
  </div>
</template>

<script>
export default {
  data () {
    return {}
  },
  mounted () {

  }
}
</script>

<style lang="less" scoped>
.video {
  display: block;
  width: 100%;
}
</style>
