# electron-vue-cloud-music

> Electron+Vue+Ant Design Vue仿网易云音乐windows客户端实战项目

<div>
  <a href="electron-vue-cloud-music:?origin=web">打开应用</a>
</div>
