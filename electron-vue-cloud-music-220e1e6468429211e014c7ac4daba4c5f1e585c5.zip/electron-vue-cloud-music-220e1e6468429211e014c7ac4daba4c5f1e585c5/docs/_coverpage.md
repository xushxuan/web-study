![logo](images/logo.png)

# electron仿网易云音乐
> Electron+Vue+Ant Design Vue仿网易云音乐windows客户端实战项目


[GitHub](https://github.com/xiaozhu188/electron-vue-cloud-music)
[Get Started](#electron-vue-cloud-music)